<link rel="stylesheet" href="{{ asset('assets/ejDiagram/ej.theme.min.css') }}">
