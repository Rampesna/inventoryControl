<style>

    @media print {
        body * {
            visibility: hidden;
        }

        #qrPrinter {
            visibility: visible;
            position: absolute;
            left: 0;
            top: 0;
        }
    }

</style>
