<link href="{{ asset('assets/jqwidgets/styles/jqx.base.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ asset('assets/jqwidgets/styles/jqx.metro.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ asset('assets/jqwidgets/styles/jqx.metrodark.css') }}" rel="stylesheet" type="text/css"/>

<style>

    @media print {
        body * {
            visibility: hidden;
        }

        #qrPrinter {
            visibility: visible;
            position: absolute;
            left: 0;
            top: 0;
        }
    }

</style>
